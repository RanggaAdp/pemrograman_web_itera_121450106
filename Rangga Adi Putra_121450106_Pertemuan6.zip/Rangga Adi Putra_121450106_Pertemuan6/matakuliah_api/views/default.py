from pyramid.view import view_config
from pyramid.response import Response
from ..models import Matakuliah

@view_config(route_name='home', renderer='home.jinja2')
def home(request):
    return {"project_name": "Matakuliah API"}

@view_config(route_name='create_matakuliah', renderer='json', request_method='POST')
def create_matakuliah(request):
    data = request.json_body
    mk = Matakuliah(**data)
    request.dbsession.add(mk)
    request.dbsession.flush()
    return {'id': mk.id, **data}