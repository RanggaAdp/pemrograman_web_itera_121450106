from pyramid.config import Configurator
import pyramid_jinja2


def main(global_config, **settings):
    config = Configurator(settings=settings)
    
    # Tambahkan ini supaya Pyramid tahu renderer jinja2
    config.include('pyramid_jinja2')
    
    # Route dasar
    config.add_route('home', '/')

    # Route CRUD untuk matakuliah
    config.add_route('create_matakuliah', '/matakuliah')            # POST
    config.add_route('get_matakuliah', '/matakuliah/{id}')           # GET by id
    config.add_route('update_matakuliah', '/matakuliah/{id}')        # PUT
    config.add_route('delete_matakuliah', '/matakuliah/{id}')        # DELETE
    config.add_route('list_matakuliah', '/matakuliah')              # GET list
    config.add_jinja2_search_path('matakuliah_api:templates')

# Arahkan URL /static/* ke folder matakuliah_api/static 
    config.add_static_view(
    name='static', 
    path='matakuliah_api:static', 
    cache_max_age=3600  # optional, untuk caching
    )

    # Scan seluruh modul untuk view_config dan lain-lain
    config.scan('matakuliah_api.views')  
    return config.make_wsgi_app()