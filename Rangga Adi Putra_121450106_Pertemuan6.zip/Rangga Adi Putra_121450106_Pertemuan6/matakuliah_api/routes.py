from pyramid.config import Configurator

def main(global_config, **settings):
    config = Configurator(settings=settings)

    # --- Tambahkan route di sini ---
    config.add_route('create_matakuliah', '/matakuliah')
    config.add_route('get_matakuliah',    '/matakuliah/{id}')
    config.add_route('update_matakuliah', '/matakuliah/{id}')
    config.add_route('delete_matakuliah', '/matakuliah/{id}')
    # ——————————————————————————————

    config.scan('matakuliah_api.views.default')
    return config.make_wsgi_app()